# Azure DevOps Ansible Pipeline

This repo accompanies [my Azure DevOps Ansible Pipeline blog post](https://www.mediaglasses.blog/2020/05/10/azure-devops-ansible-pipeline/).

Wibble
